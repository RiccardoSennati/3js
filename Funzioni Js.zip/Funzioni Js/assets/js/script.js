
//1.0

function succo(mele, arance){
    var succoFrutta = `Succo con ${mele} mele e ${arance} arance`;
    return succoFrutta;
}
document.getElementById('corretta').innerHTML = succo(4,5);
document.getElementById('sbagliata').innerHTML = succo (6);

//2.0
document.getElementById('eta').innerHTML += `${count()} anni`;
function count(){
    return 2022 - 2002; 
}

//3.0
calcolaEta = (nome, aCorrente, eta1) => {
    var calcEta = `L'anno di nascita di ${nome} è ${aCorrente - eta1}`;
    return calcEta
}
document.getElementById('persona1').innerHTML = calcolaEta('Anna', 2022, 30);
document.getElementById('persona2').innerHTML = calcolaEta('Maria', 2022, 24);

//4.0
function torta() {
    var ricetta = `Torta con ${torta2()*3} fette di mela e ${torta2()*5} fette di arancia.`;
    return ricetta;
}
function torta2() {
    var fette = 3;
    return fette;
}
document.getElementById('torta').innerHTML = torta();

//5.0
//     var sc=document.getElementById("cibo").value;
//   var sd=document.getElementById("detersivi").value;
//   var sa=document.getElementById("abiti").value;
//   document.getElementById('totale') += `${som}`;
// function som(){
//     return sc+sd+sa;
// }



